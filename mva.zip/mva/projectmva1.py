# Importing necessary libraries
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import LabelEncoder

# Load the dataset (You can choose any dataset like 'bank.csv', 'bank-additional.csv', etc.)
data = pd.read_csv('bank.csv', sep=';')  # Replace with your correct file path

# Step 1: Basic EDA (Exploratory Data Analysis)
# Checking the structure of the data
print(data.info())
print(data.describe())
print(data.columns)

# Check the unique values in 'y' column to ensure it's 'yes' and 'no'
print("Unique values in 'y' column:", data['y'].unique())

# Step 2: Distribution of Target Variable 'y' (Subscribed/Not Subscribed)
plt.figure(figsize=(8, 6))
sns.countplot(x='y', data=data)
plt.title('Distribution of Target Variable (Subscribed vs Not Subscribed)')
plt.xlabel('Subscription Status')
plt.ylabel('Count')
plt.show()

# Step 3: Distribution of Categorical Features
# Job Distribution
plt.figure(figsize=(10, 6))
sns.countplot(x='job', data=data, hue='y')
plt.title('Distribution of Job Types by Subscription')
plt.xticks(rotation=90)
plt.xlabel('Job Type')
plt.ylabel('Count')
plt.show()

# Marital Status Distribution
plt.figure(figsize=(8, 6))
sns.countplot(x='marital', data=data, hue='y')
plt.title('Distribution of Marital Status by Subscription')
plt.xlabel('Marital Status')
plt.ylabel('Count')
plt.show()

# Education Distribution
plt.figure(figsize=(8, 6))
sns.countplot(x='education', data=data, hue='y')
plt.title('Distribution of Education Levels by Subscription')
plt.xlabel('Education Level')
plt.ylabel('Count')
plt.xticks(rotation=45)
plt.show()

# Default Distribution (Credit in Default)
plt.figure(figsize=(8, 6))
sns.countplot(x='default', data=data, hue='y')
plt.title('Distribution of Credit Default by Subscription')
plt.xlabel('Default')
plt.ylabel('Count')
plt.show()

# Housing Loan Distribution
plt.figure(figsize=(8, 6))
sns.countplot(x='housing', data=data, hue='y')
plt.title('Distribution of Housing Loan by Subscription')
plt.xlabel('Has Housing Loan')
plt.ylabel('Count')
plt.show()

# Personal Loan Distribution
plt.figure(figsize=(8, 6))
sns.countplot(x='loan', data=data, hue='y')
plt.title('Distribution of Personal Loan by Subscription')
plt.xlabel('Has Personal Loan')
plt.ylabel('Count')
plt.show()

# Step 4: Feature Correlations (Correlation Matrix)
# First, we will encode categorical variables using LabelEncoder for correlation purposes
labelencoder = LabelEncoder()
data_encoded = data.copy()
for col in data_encoded.select_dtypes(include=['object']).columns:
    data_encoded[col] = labelencoder.fit_transform(data_encoded[col])

# Compute the correlation matrix
corr_matrix = data_encoded.corr()

# Plot the correlation heatmap
plt.figure(figsize=(12, 10))
sns.heatmap(corr_matrix, annot=True, cmap='coolwarm', fmt='.2f')
plt.title('Correlation Matrix of All Features')
plt.show()

# Step 5: Retrieve Subscribed Customers (y == 'yes')
# Check if 'y' column contains 'yes' and 'no', and filter for 'yes'
subscribed_customers = data[data['y'] == 'yes']

# Display the first 5 rows of the subscribed customers' data
print("Subscribed Customers' Data:")
print(subscribed_customers.head())  # Display first 5 rows

# If the dataset has a 'name' column, retrieve the names of subscribed customers
# Replace 'name' with the actual column name that contain s customer names
if 'name' in data.columns:
    print("Subscribed Customers' Names:")
    print(subscribed_customers['name'].tolist())  # List of subscribed customers' names
else:
    print("The dataset does not have a 'name' column.")
